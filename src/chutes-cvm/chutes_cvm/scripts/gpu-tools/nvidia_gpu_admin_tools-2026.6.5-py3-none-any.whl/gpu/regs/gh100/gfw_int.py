#
# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: MIT
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.
#

from gpu.regs.core import RegisterMetadata, FieldMetadata, ValueMetadata, ArrayMetadata, DeviceMetadata


# Register definitions
NV_R_BGXGWTUE = RegisterMetadata(
    name='NV_R_BGXGWTUE',
    address=0x1182cc
)

NV_R_BGXGWTUE_F_GVFZRLYZ = FieldMetadata(
    name='NV_R_BGXGWTUE_F_GVFZRLYZ',
    msb=7,
    lsb=7,
    register=NV_R_BGXGWTUE
)

NV_R_BGXGWTUE_F_GVFZRLYZ_FALSE = ValueMetadata(
    name='NV_R_BGXGWTUE_F_GVFZRLYZ_FALSE',
    value=0,
    field=NV_R_BGXGWTUE_F_GVFZRLYZ
)
NV_R_BGXGWTUE_F_GVFZRLYZ_TRUE = ValueMetadata(
    name='NV_R_BGXGWTUE_F_GVFZRLYZ_TRUE',
    value=1,
    field=NV_R_BGXGWTUE_F_GVFZRLYZ
)

NV_R_BGXGWTUE_F_MDWOYFKM = FieldMetadata(
    name='NV_R_BGXGWTUE_F_MDWOYFKM',
    msb=8,
    lsb=8,
    register=NV_R_BGXGWTUE
)

NV_R_BGXGWTUE_F_MDWOYFKM_FALSE = ValueMetadata(
    name='NV_R_BGXGWTUE_F_MDWOYFKM_FALSE',
    value=0,
    field=NV_R_BGXGWTUE_F_MDWOYFKM
)
NV_R_BGXGWTUE_F_MDWOYFKM_TRUE = ValueMetadata(
    name='NV_R_BGXGWTUE_F_MDWOYFKM_TRUE',
    value=1,
    field=NV_R_BGXGWTUE_F_MDWOYFKM
)

